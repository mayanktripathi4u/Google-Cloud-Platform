import os
import pandas as pd
from google.cloud import storage, bigquery

def process_csv(event, context):
    client = storage.Client()
    bucket_name = event['bucket']
    blob_name = event['name']
    
    bucket = client.get_bucket(bucket_name)
    blob = bucket.blob(blob_name)
    
    df = pd.read_csv(blob.download_as_text())
    
    df[['rate', 'avoidance', 'trend']] = df['recognized'].str.split(',', expand=True)
    df = df.drop(columns=['recognized'])
    
    bq_client = bigquery.Client()
    table_id = f"{os.getenv('GOOGLE_CLOUD_PROJECT')}.{os.getenv('BQ_DATASET')}.{os.getenv('BQ_TABLE')}"
    
    job = bq_client.load_table_from_dataframe(df, table_id)
    job.result()

    print(f"Loaded {df.shape[0]} rows into {table_id}.")
